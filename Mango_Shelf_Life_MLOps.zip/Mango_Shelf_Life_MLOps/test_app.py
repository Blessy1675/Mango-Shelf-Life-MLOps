
from fastapi.testclient import TestClient
from app import app

client = TestClient(app)


# Test 1: Home page
def test_home():

    response = client.get("/")

    assert response.status_code == 200


# Test 2: Valid prediction
def test_prediction():

    data = {
        "maturity_index": 3,
        "pulp_temperature": 20,
        "sweetness_brix": 15,
        "bruising_percentage": 5,
        "transport_duration": 6,
        "cooling_delay": 2,
        "packaging_type": "Carton"
    }

    response = client.post("/predict", json=data)

    assert response.status_code == 200

    assert "estimated_shelf_life_days" in response.json()


# Test 3: Invalid maturity
def test_invalid_maturity():

    data = {
        "maturity_index": 10,
        "pulp_temperature": 20,
        "sweetness_brix": 15,
        "bruising_percentage": 5,
        "transport_duration": 6,
        "cooling_delay": 2,
        "packaging_type": "Carton"
    }

    response = client.post("/predict", json=data)

    assert response.status_code == 422


# Test 4: Invalid packaging
def test_invalid_packaging():

    data = {
        "maturity_index": 3,
        "pulp_temperature": 20,
        "sweetness_brix": 15,
        "bruising_percentage": 5,
        "transport_duration": 6,
        "cooling_delay": 2,
        "packaging_type": "Glass"
    }

    response = client.post("/predict", json=data)

    assert response.status_code == 422
