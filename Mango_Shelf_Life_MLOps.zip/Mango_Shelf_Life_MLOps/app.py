
import joblib
import pandas as pd

from typing import Literal
from fastapi import FastAPI
from pydantic import BaseModel, Field

app = FastAPI(
    title="Mango Shelf Life Prediction"
)

# Load trained model
model = joblib.load("models/mango_model.pkl")


# Define input details
class MangoShipment(BaseModel):

    maturity_index: float = Field(ge=1, le=5)

    pulp_temperature: float = Field(ge=5, le=45)

    sweetness_brix: float = Field(ge=5, le=25)

    bruising_percentage: float = Field(ge=0, le=100)

    transport_duration: float = Field(ge=0, le=72)

    cooling_delay: float = Field(ge=0, le=48)

    packaging_type: Literal[
        "Carton", "Plastic", "Wooden"
    ]


@app.get("/")
def home():

    return {
        "message": "Mango Shelf Life API is running"
    }


@app.post("/predict")
def predict(data: MangoShipment):

    # Feature engineering
    heat = (
        max(data.pulp_temperature - 10, 0)
        * data.transport_duration
    )

    damage = (
        data.bruising_percentage
        + 2 * data.cooling_delay
    )

    # Prepare input
    input_data = pd.DataFrame([{
        "maturity_index": data.maturity_index,
        "pulp_temperature": data.pulp_temperature,
        "sweetness_brix": data.sweetness_brix,
        "bruising_percentage": data.bruising_percentage,
        "transport_duration": data.transport_duration,
        "cooling_delay": data.cooling_delay,
        "packaging_type": data.packaging_type,
        "heat_exposure_index": heat,
        "handling_damage_index": damage
    }])

    # Predict shelf life
    prediction = float(model.predict(input_data)[0])

    return {
        "estimated_shelf_life_days": round(
            max(0, prediction), 2
        ),
        "unit": "days"
    }
